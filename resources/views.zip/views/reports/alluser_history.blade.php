<html>
    @if(count($users)>0)
    @foreach($users as $user)
    <table>
        <thead>
            <tr style="background: #D7D7D7">
                <th>Last Name</th>
                <th>First Name</th>
                <th>Middle Name</th>
                <th>Birthday</th>
                <th>User ID</th>
                <th>Email</th>
            </tr>
             
            <tr>
                <td>{{ $user->last_name }}</td>
                <td>{{ $user->first_name }}</td>
                <td>{{ $user->middle_name }}</td>
                <td>{{ $user->date_of_birth }}</td>
                <td>{{ $user->inmate_id }}</td>
                <td>@if($user->inmateEmail && $user->inmateEmail->email) {{ $user->inmateEmail->email }} @else No Email @endif</td>
            </tr>

        </thead>
    </table>
    <table>
        <thead>
            <tr style="background: #FFE495">
                <th>S. No.</th>
                <th>Service Name</th>
                <th>Activity Date</th>
                <th>Start time</th>
                <th>End Time</th>
                <th>Charge ($)</th> 

            </tr>
            @php($count = 1 )
            @if(count($user->vendorsInfoHistory) > 0 )
            @foreach($user->vendorsInfoHistory as $val)
            @if($val->end_time !== '')
            <tr>
                <td>{{ $count++ }}</td>
                <td>{{ $val->vendorDetailsNames->name }}</td>
                <td>{{ $val->date }}</td>
                <td>{{ $val->start_time }}</td>
                <td>{{ $val->end_time }}</td>
                <td>@if(!empty($val->vendorDetails->charges)) {{ $val->vendorDetails->charges }} @elseif($val->vendorDetailsNames->type == 0) Free @else -- @endif </td>
            </tr>
            @endif
            @endforeach
            @else 
            <tr>

                <td>1</td>
                <td>None</td>
                <td> -</td>
                <td> -</td>
                <td> -</td>
                <td>No Data Found</td>                                           
            </tr>
            @endif
        </thead>
    </table>
    @endforeach
    @endif
</html>
