@extends('layouts.default')
@section('content')    

<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<style>
  .toggle.ios, .toggle-on.ios, .toggle-off.ios { border-radius: 20px; }
  .toggle.ios .toggle-handle { border-radius: 20px; }
</style>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            @if (isset($facilityInfo)) Edit
                @else Add
            @endif Facility
        </h1>
        <ol class="breadcrumb">
            <li><a href="{{route('superadmin.index')}}"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="{{route('facility.list')}}">Facility List</a></li>
            <li class="active">@if (isset($facilityInfo)) Edit
                @else Add
                @endif Facility
            </li>
        </ol>
    </section>
    
     @if(Session::has('message'))
    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
    @endif
    
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">@if (isset($facilityInfo)) Edit
                            @else Add
                            @endif Facility
                        </h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" method="post" action="javascript:;" id="facilityData">
                         {{ csrf_field() }}
                        <input type="hidden" class="form-control" name="id" value="{{ $facilityInfo->id or '' }}">
                        <div class="box-body">
                             <div class="row no-margin"> <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Facility ID <i class="requiredInput text-red">*</i></label>
                                    <input type="text" class="form-control" name="facility_id" value="{{ $facilityInfo->facility_id or '' }}" maxLength = "11" id="facility_id" placeholder="Please enter first id"  @isset($facilityInfo) disabled @endisset/>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">First Name<i class="requiredInput text-red">*</i></label>
                                    <input type="text" class="form-control" name="first_name" value="{{ $facilityInfo->first_name or '' }}" id="first_name" placeholder="Please enter first name">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Last Name<i class="requiredInput text-red">*</i></label>
                                    <input type="text" class="form-control" name="last_name" value="{{ $facilityInfo->last_name or '' }}" id="last_name" placeholder="Please enter last name">
                                </div>
                            </div>
                        </div>
                            <div class="row no-margin">  <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Total User<i class="requiredInput text-red">*</i></label>
                                    <input type="text" class="form-control" name="total_inmate" value="{{ $facilityInfo->total_inmate or '' }}" id="total_inmate" placeholder="Please enter total User number">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email<i class="requiredInput text-red">*</i></label>
                                    <input type="text" class="form-control" name="email" value="{{ $facilityInfo->email or '' }}" id="email" placeholder="Please enter email" >
                                </div>
                            </div> </div>
                           <div class="row no-margin">   <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Username <i class="requiredInput text-red">*</i></label>
                                    <input type="text" class="form-control" name="username" value="{{ $facilityInfo->username or '' }}" id="username" placeholder="Please enter user name" @isset($facilityInfo) disabled @endisset>
                                </div>
                            </div>
                           
                             <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Phone </label>
                                    <input type="text" class="form-control" name="phone" value="{{ $facilityInfo->phone or '' }}" placeholder="Please enter phone">
                                </div>
                            </div> </div>
                             <div class="row no-margin">   <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Facility Name <i class="requiredInput text-red">*</i></label>
                                    <input id="facility_name" type="text" class="form-control" name="facility_name" value="{{ $facilityInfo->facility_name or '' }}"  placeholder="Please enter user facility name" >
                                    
                                </div>
                            </div>
                           
                             <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Location </label>
                                    <input type="text" class="form-control" name="location" value="{{ $facilityInfo->location or '' }}" placeholder="Please enter location">
                                </div>
                            </div> </div>
                           <div class="row no-margin"> <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Twilio Phone <i class="requiredInput text-red"></i></label>
                                    <input type="hidden"  id="output" name="twilio_number"  value="{{ $facilityInfo->twilio_number or '' }}"/>
                                    <input id="phone" type="tel" class="form-control" value="{{ $facilityInfo->twilio_number or '' }}" />	
                                    <span id="valid-msg" class="hide">✓ Valid</span>
                                    <span id="error-msg" class="hide">Invalid number</span>
                                </div>
                            </div>
                             <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">State </label>
                                    <input type="text" class="form-control" name="state" value="{{ $facilityInfo->state or '' }}" id="state" placeholder="Please enter state">
                                </div>
                            </div> </div>
                           <div class="row no-margin"> <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">City </label>
                                    <input type="text" class="form-control" name="city" value="{{ $facilityInfo->city or '' }}" id="city" placeholder="Please enter city">
                                </div>
                            </div>
                             <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Zip </label>
                                    <input type="text" class="form-control" name="zip" value="{{ $facilityInfo->zip or '' }}" id="zip" placeholder="Please enter zip">
                                </div>
                            </div> </div>
                           <div class="row no-margin"> <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Address Line 1 </label>
                                    <input type="text" class="form-control" value="{{ $facilityInfo->address_line_1 or '' }}" name="address_line_1" id="address_line_1" placeholder="Please enter address line 1">
                                </div>
                            </div>
                              <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Address Line 2 </label>
                                    <input type="text" class="form-control" name="address_line_2" value="{{ $facilityInfo->address_line_2 or '' }}" id="address_line_2" placeholder="Please enter address line 2">
                                </div>
                            </div> </div>
                           
                            <div class="row no-margin">
                                  @if(!isset($facilityInfo->id))
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Password<i class="requiredInput text-red">*</i></label>
                                    <input type="password" class="form-control" name="password" id="password" placeholder="Please enter password">
                                </div>
                            </div> 
                         @endif
                          <div class="row no-margin"><div class="col-md-6">
                                 <div class="form-group">
                                     <label for="exampleInputEmail1">Tablet Charge(Cents/Minutes)<i class="requiredInput text-red">*</i></label>
                                     <input type="text" class="form-control" name="tablet_charge" value="{{ $facilityInfo->tablet_charge or '' }}" id="zip" placeholder="Please enter tablet charges">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row">
                                <div class="col-md-4">
                                <div class="form-group">
                                    <!-- Default checked -->
                                    <br>
                                    <label  for="exampleInputEmail1">CPC Funding</label> &nbsp;
                                    <input id="f_status" type="checkbox" class="form-control"  data-toggle="toggle" data-style="ios" data-on="Enabled" data-off="Disabled" data-size="small"  value="{{$facilityInfo->cpc_funding or '0'}}" <?php if (isset($facilityInfo->cpc_funding) && $facilityInfo->cpc_funding  == 1): ?>
                                        checked
                                    <?php endif ?>>
                                    <input id="cpc_funding" type="hidden" name="cpc_funding" value="{{$facilityInfo->cpc_funding or '0'}}">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <!-- Default checked -->
                                    <br>
                                    <label for="exampleInputEmail1">Contact Approval</label> &nbsp;
                                    <input id="contact_app_switch" type="checkbox" class="form-control"  data-toggle="toggle"  title="Tooltip on top" data-style="ios" data-on="Enabled" data-off="Disabled" data-size="small"  value="{{$facilityInfo->cntct_approval or '1'}}" <?php if (isset($facilityInfo->cntct_approval) && $facilityInfo->cntct_approval  == 1 || !isset($facilityInfo->cntct_approval)): ?>
                                        checked
                                    <?php endif ?>>
                                    <input id="cntct_approval" type="hidden" name="cntct_approval" value="{{$facilityInfo->cntct_approval or '1'}}">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <!-- Default checked -->
                                    <br>
                                    <label for="exampleInputEmail1">Device On/Off</label> &nbsp;
                                    <input id="device_status_switch" type="checkbox" class="form-control"  data-toggle="toggle" data-onstyle="success" data-offstyle="danger"  title="Tooltip on top" data-style="ios" data-on="On" data-off="Off" data-size="small"  value="{{$facilityInfo->cntct_approval or '1'}}" <?php if (isset($facilityInfo->device_status) && $facilityInfo->device_status  == 1 || !isset($facilityInfo->device_status)): ?>
                                        checked
                                    <?php endif ?>>
                                    <input id="device_status" type="hidden" name="device_status" value="{{$facilityInfo->device_status or '1'}}">
                                </div>
                            </div>
                        </div>

                            </div>
                            <div class="col-md-6">
                                <label>Free Minutes<i class="requiredInput text-red">*</i></label>
                                <input type="text" class="form-control" value="{{ $facilityInfo->free_minutes or '' }}"name="free_minutes" placeholder="Please enter free minutes">
                                
                            </div>
                        </div> </div>
                             <div class="row no-margin"> <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email Charge ($/per Email) </label>
                                    <input type="text" class="form-control" value="{{ $facilityInfo->email_charges or '' }}" name="email_charges" id="email_charges" placeholder="Please enter email charges">
                                </div>
                            </div>
                              <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">SMS Charge ($/per SMS)</label>
                                    <input type="text" class="form-control" name="sms_charges" value="{{ $facilityInfo->sms_charges or '' }}" id="sms_charges" placeholder="Please enter sms charges">
                                </div>
                            </div> </div>
                            
                        <!-- /.box-body -->
                        <div class="box-footer text-right">
                             <div class="col-md-12">
                                <a href="{{action('FacilityController@facilityListUI')}}" class="btn btn-primary" >Cancel</a>
                                <button type="submit" class="btn btn-primary" id="{{ isset($facilityInfo) ? 'facilityEditDataSend' : 'facilityAddDataSend' }}">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!--/.col (right) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script src="{{ asset('/assets/js/customJS/facility.js') }}" type="text/javascript"></script>
<script src="<?php echo asset('/'); ?>assets/build/js/intlTelInput.js" type="text/javascript"></script>
  <script>
    var telInput = $("#phone"),
    output = $("#output");
    errorMsg = $("#error-msg"),
    validMsg = $("#valid-msg");
    $("#phone").intlTelInput({ 
        initialCountry: "auto",
        geoIpLookup: function(callback) {
          $.get('https://ipinfo.io', function() {}, "jsonp").always(function(resp) {
            var countryCode = (resp && resp.country) ? resp.country : "";
            callback(countryCode);
          });
        },
        nationalMode: true,
      utilsScript: "<?php echo asset('/'); ?>assets/build/js/utils.js"
    });
    
    var reset = function() {
    var intlNumber = telInput.intlTelInput("getNumber");
    if (intlNumber) {
      output.val("" + intlNumber);
    } else {
      output.val("Please enter a number below");
    }
  telInput.removeClass("error");
  errorMsg.addClass("hide");
  validMsg.addClass("hide");
};

// on blur: validate
telInput.blur(function() {
  reset();
  if ($.trim(telInput.val())) {
    if (telInput.intlTelInput("isValidNumber")) {
      validMsg.removeClass("hide");
    } else {
      telInput.addClass("error");
      errorMsg.removeClass("hide");
    }
  }
});

// on keyup / change flag: reset
telInput.on("keyup change", reset);


  </script>
@stop