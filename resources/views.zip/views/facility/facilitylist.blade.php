@extends('layouts.default')
@section('content')    
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<!-- Toaster  -->
<link rel="stylesheet" type="text/css" href="{{ asset('assets/toaster/toaster.css')}}">
<script src="{{ asset('assets/toaster/toaster.js')}}"></script>

<style>
    .ui-autocomplete { 
        cursor:pointer; 
        height:120px; 
        overflow-y:scroll;
    }
    .toggle.ios, .toggle-on.ios, .toggle-off.ios { border-radius: 20px; }
  .toggle.ios .toggle-handle { border-radius: 20px; }  

</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>Facility List</h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Facility</a></li>
            <li class="active">Facility List</li>
        </ol>
    </section>

    @if(Session::has('message'))
    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
    @endif

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header text-right">
                        @role('Super Admin')
                        <kbd>Device ON/OFF</kbd>
                        <input id="toggle-one" name="devicetoggle" type="checkbox"  data-toggle="toggle" data-style="ios" data-onstyle="success" data-offstyle="danger" value="{{$device_off->content or '1'}}" data-on="ON" data-off="OFF" data-size="small" @if(isset($device_off->content) && $device_off->content == 1) checked @endif>
                        <input id="device_off" type="hidden" name="alldevice_off" value="{{$device_off->content or '1'}}">
                        <input type="hidden" id="deviceoff_id" name="devicoff_id" value="{{$device_off->id or ''}}">

                        <a href="{{action('ExcelController@facilityReport')}}" class="btn btn-info"><i class="fa fa-file-excel-o" aria-hidden="true"></i> Export Facilities</a>
                        <a href="{{action('FacilityController@addFacilityUI')}}" class="btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i> Facility</a>
                        @else
                        @can('Download Facility List Report')
                        <a href="{{action('ExcelController@facilityReport')}}" class="btn btn-info"><i class="fa fa-file-excel-o" aria-hidden="true"></i> Export Facilities</a>
                        @endcan
                        @can('Manage Facility')
                        <a href="{{action('FacilityController@addFacilityUI')}}" class="btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i> Facility</a>
                        @endcan
                        @endrole                       

                    </div>

                    <!-- Flash message -->
                    <div class="alert alert-success" id="alertDiv" style="display:none">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>    
                        <span id="alert"></span>
                    </div>
                    <!-- Flash message -->

                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>Facility Name</th>
                                    <th>Email</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Phone</th>
                                    <th>City</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php($count = 1)
                                @if(count($facilityList)>0)
                                @foreach($facilityList as $val)
                                <tr>
                                    <td>{{ $count++ }}</td>
                                    <td>{{ $val->facility_name }}</td>
                                    <td>{{ $val->email }}</td>
                                    <td>{{ $val->first_name }}</td>
                                    <td>{{ $val->last_name }}</td>
                                    <td>{{ $val->phone }}</td>
                                    <td>{{ $val->city }}</td>
                                    <td>

                                        @role('Super Admin')
                                        <a href="{{route('facility.view', ['id' => $val->id] )}}"<i class="fa fa-eye" data-toggle="tooltip" title="View"></i>&nbsp;&nbsp;&nbsp;</a>
                                        <a href="{{route('facility.add', ['id'=> $val->id] )}}"><i class="fa fa-pencil" data-toggle="tooltip" title="Edit"></i>&nbsp;&nbsp;&nbsp;</a>
                                        <a href="{{ route('facility.servicedetails', ['id' => $val->facility_user_id]) }}" data-toggle="tooltip" title="Service Details" ><i class="fa fa-server"></i>&nbsp;&nbsp;&nbsp;</a>

                                        <a href='javascript:;' token="{{ csrf_token() }}" class="facilityDelete" id="{{$val->id}}"><i class="fa fa-trash" data-toggle="tooltip" title="Delete"></i>&nbsp;&nbsp;&nbsp;</a>
                                        <a href='javascript:;' token="{{ csrf_token() }}" class="facilitymonthlyReport" facility_id="{{$val->id}}">
                                            <i class="fa fa-files-o" aria-hidden="true" data-toggle="tooltip" title="Download Monthly Report"></i> &nbsp;&nbsp;&nbsp;</a>
                                        <a href="{{ route('facility_service_report', ['id' => $val->id]) }}" data-toggle="tooltip" title="Download Service Report"> <i class="fa fa-file-excel-o"></i>&nbsp;&nbsp;&nbsp;</a>
                                        <a href="{{ route('perfacilityreport', ['id' => $val->id]) }}" data-toggle="tooltip" title="Download Facility Report" ><i class="fa fa-file-excel-o"></i>&nbsp;&nbsp;&nbsp;</a>
                                        <a href="{{ route('facilityusersreport', ['id' => $val->id]) }}" data-toggle="tooltip" title="Download Users Report" ><i class="fa fa-file-excel-o"></i>&nbsp;&nbsp;&nbsp;</a>
                                        <a href="{{ route('inactiveuser_facilityreport', ['id' => $val->id]) }}" data-toggle="tooltip" title="Download Inactive Users Report" ><i class="fa fa-file-excel-o"></i>&nbsp;&nbsp;&nbsp;</a>
                                        <a href="{{ route('all_user_service_history_report', ['id' => $val->facility_user_id]) }}" data-toggle="tooltip" title="Download User's Service History Report" ><i class="fa fa-file-excel-o"></i>&nbsp;&nbsp;&nbsp;</a>
                                        @else
                                        @can('Manage Facility')
                                        <a href="{{route('facility.view', ['id' => $val->id] )}}"<i class="fa fa-eye" data-toggle="tooltip" title="View"></i>&nbsp;&nbsp;&nbsp;</a>
                                        <a href="{{route('facility.add', ['id'=> $val->id] )}}"><i class="fa fa-pencil" data-toggle="tooltip" title="Edit"></i>&nbsp;&nbsp;&nbsp;</a>                                       
                                        <a href='javascript:;' token="{{ csrf_token() }}" class="facilityDelete" id="{{$val->id}}"><i class="fa fa-trash" data-toggle="tooltip" title="Delete"></i>&nbsp;&nbsp;&nbsp;</a>
                                        @endcan
                                        @can('Enable Services For Facility')
                                        <a href="{{ route('facility.servicedetails', ['id' => $val->facility_user_id]) }}" data-toggle="tooltip" title="Service Details" <i class="fa fa-server"></i>&nbsp;&nbsp;&nbsp;</a>
                                        @endcan
                                        @can('Download Facility Service Report')
                                        <a href="{{ route('facility_service_report', ['id' => $val->id]) }}" data-toggle="tooltip" title="Download Service Report" <i class="fa fa-file-excel-o"></i>&nbsp;&nbsp;&nbsp;</a>
                                        @endcan
                                        @can('Download Facility Report')
                                        <a href="{{ route('perfacilityreport', ['id' => $val->id]) }}" data-toggle="tooltip" title="Download Facility Report" <i class="fa fa-file-excel-o"></i>&nbsp;&nbsp;&nbsp;</a>
                                        @endcan
                                        @can('Download Facility Users Report')
                                        <a href="{{ route('facilityusersreport', ['id' => $val->id]) }}" data-toggle="tooltip" title="Download Users Report" <i class="fa fa-file-excel-o"></i>&nbsp;&nbsp;&nbsp;</a>
                                        @endcan
                                        @can('Download Inactive Facility List Report')
                                        <a href="{{ route('inactiveuser_facilityreport', ['id' => $val->id]) }}" data-toggle="tooltip" title="Download Inactive Users Report" <i class="fa fa-file-excel-o"></i>&nbsp;&nbsp;&nbsp;</a>
                                        @endcan
                                        @can('Download Users Service History')
                                        <a href="{{ route('all_user_service_history_report', ['id' => $val->facility_user_id]) }}" data-toggle="tooltip" title="Download Inactive Users Report" <i class="fa fa-file-excel-o"></i>&nbsp;&nbsp;&nbsp;</a>
                                        @endcan
                                        @endrole 
                                    </td>
                                </tr>
                                @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>
                    <!-- /.box-body -->

                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
        <div class="modal fade" id="ReportModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel">Generate Report</h4>
                    </div>
                    <div class="modal-body" >
                        <form role="form" method="post" action="javascript:;" id="Report_Fetch">
                            <input type="hidden" name="facility_id" >
                        {{ csrf_field() }}
                        <div class="box-body">
                            <div class="row no-margin">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Select Report Type<i class="requiredInput text-red">*</i></label>
                                        <select class="form-control" name="report_type" id="report_type">
                                            <option value="rental">Rental(Android charges)</option>
                                            <option value="emailing"  >E-mailing</option> 
                                            <option value="texting"  >Texting</option> 
                                            <option value="vendor"> Paid Services </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6 vendor_detail ui-widget" style="display:none;">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Services Name<i class="requiredInput text-red">*</i></label>
                                        <input  name="vendor_name"  placeholder="Search Services" value="All" class="form-control vendor_name" >
                                        <input type="hidden" name="service_id" class="service_id" >
                                        <div id="browsers">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row no-margin">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Start Date <i class="requiredInput text-red">*</i></label>
                                        <input type="text" readonly="true" autocomplete="off" name="start_date" class="form-control datepicker_start" >
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                       <label for="exampleInputEmail1">End Date <i class="requiredInput text-red">*</i></label>
                                       <input type="text" readonly="true" autocomplete="off" name="end_date" class="form-control datepicker_end" > 

                                    </div>
                                </div>
                            </div>
                        </div>
                        </form>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" id="download_report" >Download Report</button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
<script src="{{ asset('/assets/js/customJS/facility.js') }}" type="text/javascript"></script>
@stop