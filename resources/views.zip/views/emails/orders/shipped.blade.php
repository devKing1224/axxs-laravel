@component('mail::message')
# {{ $content['title'] }}

{{ $content['body'] }}



<p>If you have any questions, please contact us at info@axxstablet.com.</p>
<p>Sincerely,</p>
Axxs Tablet  App Team,<br>
http://www.axxstablet.com
@endcomponent